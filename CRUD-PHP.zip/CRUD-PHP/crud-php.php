<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro de Alunos</title>
    <style>
        body { font-family: Arial, sans-serif; }
        form { margin-bottom: 20px; }
        input[type="text"], input[type="email"] { width: 300px; padding: 10px; margin: 5px 0; }
        table { width: 100%; border-collapse: collapse; }
        table, th, td { border: 1px solid black; padding: 10px; text-align: left; }
    </style>
</head>
<body>

<h1>Cadastro de Alunos</h1>

<?php
// Configurações do banco de dados
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "escola";

// Criando conexão
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificando conexão
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

// Função para limpar entradas do formulário
function limparEntrada($data) {
    return htmlspecialchars(stripslashes(trim($data)));
}

// Inicializar variáveis
$id = $nome = $email = $curso = "";

// Adicionar aluno
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["adicionar"])) {
    $nome = limparEntrada($_POST["nome"]);
    $email = limparEntrada($_POST["email"]);
    $curso = limparEntrada($_POST["curso"]);
    
    $sql = "INSERT INTO alunos (nome, email, curso) VALUES ('$nome', '$email', '$curso')";
    
    if ($conn->query($sql) === TRUE) {
        echo "<p>Aluno cadastrado com sucesso!</p>";
        // Limpar campos após adicionar
        $nome = $email = $curso = "";
    } else {
        echo "Erro: " . $sql . "<br>" . $conn->error;
    }
}

// Verificar se está editando um aluno
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["editar"])) {
    $id = $_POST["id"];
    
    // Buscar o aluno pelo ID
    $sql = "SELECT * FROM alunos WHERE id=$id";
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        // Preencher os campos com os dados do aluno
        $row = $result->fetch_assoc();
        $nome = $row["nome"];
        $email = $row["email"];
        $curso = $row["curso"];
    }
}

// Atualizar aluno
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["atualizar"])) {
    $id = limparEntrada($_POST["id"]);
    $nome = limparEntrada($_POST["nome"]);
    $email = limparEntrada($_POST["email"]);
    $curso = limparEntrada($_POST["curso"]);
    
    $sql = "UPDATE alunos SET nome='$nome', email='$email', curso='$curso' WHERE id=$id";
    
    if ($conn->query($sql) === TRUE) {
        echo "<p>Aluno atualizado com sucesso!</p>";
        // Limpar campos após atualizar
        $id = $nome = $email = $curso = "";
    } else {
        echo "Erro: " . $sql . "<br>" . $conn->error;
    }
}

// Excluir aluno
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["excluir"])) {
    $id = limparEntrada($_POST["id"]);
    
    $sql = "DELETE FROM alunos WHERE id=$id";
    
    if ($conn->query($sql) === TRUE) {
        echo "<p>Aluno excluído com sucesso!</p>";
    } else {
        echo "Erro: " . $sql . "<br>" . $conn->error;
    }
}
?>

<!-- Formulário de cadastro/atualização -->
<form method="POST" action="">
    <input type="hidden" name="id" value="<?php echo $id; ?>">
    Nome: <input type="text" name="nome" value="<?php echo $nome; ?>" required><br>
    E-mail: <input type="email" name="email" value="<?php echo $email; ?>" required><br>
    Curso: <input type="text" name="curso" value="<?php echo $curso; ?>" required><br>
    <?php if ($id): ?>
        <button type="submit" name="atualizar">Atualizar Aluno</button>
    <?php else: ?>
        <button type="submit" name="adicionar">Adicionar Aluno</button>
    <?php endif; ?>
</form>

<h2>Lista de Alunos</h2>
<table>
    <thead>
        <tr>
            <th>ID</th>
            <th>Nome</th>
            <th>E-mail</th>
            <th>Curso</th>
            <th>Ações</th>
        </tr>
    </thead>
    <tbody>
        <?php
        // Listar alunos
        $sql = "SELECT * FROM alunos";
        $result = $conn->query($sql);
        
        if ($result->num_rows > 0) {
            // Exibir os dados de cada linha
            while($row = $result->fetch_assoc()) {
                echo "<tr>
                        <td>" . $row["id"] . "</td>
                        <td>" . $row["nome"] . "</td>
                        <td>" . $row["email"] . "</td>
                        <td>" . $row["curso"] . "</td>
                        <td>
                            <form method='POST' action='' style='display:inline;'>
                                <input type='hidden' name='id' value='" . $row["id"] . "'>
                                <button type='submit' name='editar'>Editar</button>
                            </form>
                            <form method='POST' action='' style='display:inline;'>
                                <input type='hidden' name='id' value='" . $row["id"] . "'>
                                <button type='submit' name='excluir'>Excluir</button>
                            </form>
                        </td>
                    </tr>";
            }
        } else {
            echo "<tr><td colspan='5'>Nenhum aluno cadastrado.</td></tr>";
        }
        ?>
    </tbody>
</table>

<?php
// Fechar conexão
$conn->close();
?>

</body>
</html>
