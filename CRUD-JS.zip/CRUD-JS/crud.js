// Função para salvar um novo usuário ou atualizar um existente
function saveUser(event) {
  event.preventDefault();

  // Obtém os valores dos campos do formulário
  const userId = document.getElementById('user-id').value;
  const name = document.getElementById('name').value;
  const email = document.getElementById('email').value;

  // Carrega a lista de usuários do LocalStorage
  let users = JSON.parse(localStorage.getItem('users')) || [];

  if (userId) {
      // Se o ID existir, estamos atualizando um usuário existente
      for (let i = 0; i < users.length; i++) {
        if (users[i].id === userId) {
            users[i] = { id: userId, name: name, email: email };
        }
    }
    
  } else {
      // Senão, cria um novo usuário com um ID único
      const newUser = {
          id: new Date().getTime().toString(), // Usamos o timestamp como ID
          name: name,
          email: email
      };
      users.push(newUser); // Adiciona o novo usuário na lista
  }

  // Salva os usuários atualizados no LocalStorage
  localStorage.setItem('users', JSON.stringify(users));

  // Reseta o formulário
  document.getElementById('user-form').reset();
  document.getElementById('user-id').value = '';

  // Atualiza a tabela de usuários
  displayUsers();
}

// Função para exibir os usuários na tabela
function displayUsers() {
  const users = JSON.parse(localStorage.getItem('users')) || [];
  const userTable = document.querySelector('#user-table tbody');

  // Limpa a tabela antes de inserir os dados
  userTable.innerHTML = '';

  // Insere cada usuário como uma linha na tabela
  users.forEach(user => {
      const row = document.createElement('tr');
      row.innerHTML = `
          <td>${user.name}</td>
          <td>${user.email}</td>
          <td>
              <button onclick="editUser('${user.id}')">Editar</button>
              <button onclick="deleteUser('${user.id}')">Excluir</button>
          </td>
      `;
      userTable.appendChild(row);
  });
}

// Função para editar um usuário
function editUser(id) {
  const users = JSON.parse(localStorage.getItem('users')) || [];
  const user = users.find(user => user.id === id);

  // Preenche os campos do formulário com os dados do usuário a ser editado
  document.getElementById('user-id').value = user.id;
  document.getElementById('name').value = user.name;
  document.getElementById('email').value = user.email;
}

// Função para excluir um usuário
function deleteUser(id) {
  let users = JSON.parse(localStorage.getItem('users')) || [];
  
  // Filtra a lista para remover o usuário com o ID fornecido
  users = users.filter(user => user.id !== id);

  // Salva a nova lista no LocalStorage
  localStorage.setItem('users', JSON.stringify(users));

  // Atualiza a tabela de usuários
  displayUsers();
}

// Evento para salvar ou atualizar o usuário ao enviar o formulário
document.getElementById('user-form').addEventListener('submit', saveUser);

// Exibe os usuários na tabela ao carregar a página
document.addEventListener('DOMContentLoaded', displayUsers);
